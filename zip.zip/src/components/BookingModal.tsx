import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, ChevronLeft, ChevronRight, CheckCircle2 } from 'lucide-react';
import { useBookingStore } from '../store/bookingStore';

interface BookingModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialService?: string;
}

export default function BookingModal({ isOpen, onClose, initialService }: BookingModalProps) {
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({
    name: '',
    age: '',
    phone: '',
    service: initialService || '',
    date: '',
    time: '',
  });
  const [isSuccess, setIsSuccess] = useState(false);
  const addBooking = useBookingStore((state) => state.addBooking);

  if (!isOpen) return null;

  const totalSteps = 4;

  const handleNext = () => {
    if (step < totalSteps) setStep(step + 1);
  };

  const handlePrev = () => {
    if (step > 1) setStep(step - 1);
  };

  const isStepValid = () => {
    switch (step) {
      case 1:
        return formData.name.trim() !== '' && formData.age.trim() !== '';
      case 2:
        return formData.phone.trim() !== '';
      case 3:
        return formData.service.trim() !== '';
      case 4:
        return formData.date.trim() !== '' && formData.time.trim() !== '';
      default:
        return false;
    }
  };

  const handleSubmit = () => {
    // Save to local storage (Admin Panel)
    addBooking({
      ...formData,
      id: Date.now().toString(),
      status: 'جديد',
      createdAt: new Date().toISOString(),
    });

    setIsSuccess(true);

    // Prepare WhatsApp message
    const message = `استمارة حجز موعد جديد (من الموقع الإلكتروني):
👤 اسم المريض: ${formData.name}
🎂 العمر: ${formData.age} سنة
📱 رقم الهاتف: ${formData.phone}
🩺 نوع الحالة: ${formData.service}
📅 التوقيت المفضل: ${formData.date} - ${formData.time}
💵 كشفية الطبيب: 50,000 دينار عراقي

يرجى من السكرتارية تأكيد الموعد مع المريض.`;

    const encodedMessage = encodeURIComponent(message);
    const whatsappNumber = '9641234567890'; // Replace with actual number

    // Redirect to WhatsApp after a short delay to show success message
    setTimeout(() => {
      window.open(`https://wa.me/${whatsappNumber}?text=${encodedMessage}`, '_blank');
      onClose();
      // Reset state after closing
      setTimeout(() => {
        setStep(1);
        setIsSuccess(false);
        setFormData({ name: '', age: '', phone: '', service: '', date: '', time: '' });
      }, 500);
    }, 2500);
  };

  const slideVariants = {
    enter: (direction: number) => ({
      x: direction > 0 ? 50 : -50,
      opacity: 0,
    }),
    center: {
      zIndex: 1,
      x: 0,
      opacity: 1,
    },
    exit: (direction: number) => ({
      zIndex: 0,
      x: direction < 0 ? 50 : -50,
      opacity: 0,
    }),
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 sm:p-6">
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        onClick={onClose}
        className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm"
      />
      
      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 20 }}
        className="relative w-full max-w-lg bg-white rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]"
      >
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
          <h3 className="text-lg font-bold text-slate-900">حجز موعد جديد</h3>
          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-slate-600 hover:bg-slate-100 rounded-full transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {isSuccess ? (
          <div className="p-8 text-center flex flex-col items-center justify-center min-h-[300px]">
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ type: "spring", stiffness: 200, damping: 20 }}
              className="w-20 h-20 bg-teal-100 text-teal-600 rounded-full flex items-center justify-center mb-6"
            >
              <CheckCircle2 className="w-10 h-10" />
            </motion.div>
            <h4 className="text-2xl font-bold text-slate-900 mb-2">تم تسجيل طلب الحجز بنجاح</h4>
            <p className="text-slate-600 mb-6">
              سيقوم سكرتير العيادة بالاتصال بك لتأكيد الموعد. جاري تحويلك للواتساب...
            </p>
          </div>
        ) : (
          <>
            {/* Progress Bar */}
            <div className="px-6 pt-6">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium text-teal-600">الخطوة {step} من {totalSteps}</span>
                <span className="text-sm text-slate-400">
                  {step === 1 && 'المعلومات الشخصية'}
                  {step === 2 && 'رقم التواصل'}
                  {step === 3 && 'نوع الحالة'}
                  {step === 4 && 'الموعد المفضل'}
                </span>
              </div>
              <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                <motion.div
                  className="h-full bg-teal-500 rounded-full"
                  initial={{ width: 0 }}
                  animate={{ width: `${(step / totalSteps) * 100}%` }}
                  transition={{ duration: 0.3 }}
                />
              </div>
            </div>

            {/* Form Content */}
            <div className="p-6 flex-1 overflow-y-auto overflow-x-hidden relative min-h-[250px]">
              <AnimatePresence mode="wait" custom={1}>
                <motion.div
                  key={step}
                  custom={1}
                  variants={slideVariants}
                  initial="enter"
                  animate="center"
                  exit="exit"
                  transition={{ type: "tween", duration: 0.3 }}
                  className="absolute inset-0 p-6"
                >
                  {step === 1 && (
                    <div className="space-y-4">
                      <div className="flex flex-col sm:flex-row gap-4">
                        <div className="flex-1">
                          <label className="block text-sm font-medium text-slate-700 mb-1">الاسم الثلاثي</label>
                          <input
                            type="text"
                            value={formData.name}
                            onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                            className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-teal-500 focus:border-teal-500 outline-none transition-all"
                            placeholder="أدخل اسمك الكامل"
                            autoFocus
                          />
                        </div>
                        <div className="w-full sm:w-1/3">
                          <label className="block text-sm font-medium text-slate-700 mb-1">العمر</label>
                          <input
                            type="number"
                            value={formData.age}
                            onChange={(e) => setFormData({ ...formData, age: e.target.value })}
                            className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-teal-500 focus:border-teal-500 outline-none transition-all"
                            placeholder="سنة"
                          />
                        </div>
                      </div>
                    </div>
                  )}

                  {step === 2 && (
                    <div className="space-y-4">
                      <div>
                        <label className="block text-sm font-medium text-slate-700 mb-1">رقم الموبايل</label>
                        <input
                          type="tel"
                          value={formData.phone}
                          onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                          className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-teal-500 focus:border-teal-500 outline-none transition-all text-left"
                          placeholder="07X XXXX XXXX"
                          dir="ltr"
                          autoFocus
                        />
                      </div>
                    </div>
                  )}

                  {step === 3 && (
                    <div className="space-y-4">
                      <div>
                        <label className="block text-sm font-medium text-slate-700 mb-1">نوع الحالة أو الخدمة</label>
                        <select
                          value={formData.service}
                          onChange={(e) => setFormData({ ...formData, service: e.target.value })}
                          className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-teal-500 focus:border-teal-500 outline-none transition-all bg-white"
                          autoFocus
                        >
                          <option value="" disabled>اختر الخدمة المطلوبة</option>
                          <option value="كشفية طبية واستشارة">كشفية طبية واستشارة</option>
                          <option value="زراعة الأسنان">زراعة الأسنان</option>
                          <option value="علاج العصب">علاج العصب</option>
                          <option value="ابتسامة هوليود">ابتسامة هوليود</option>
                          <option value="تجميل اللثة">تجميل اللثة</option>
                          <option value="أخرى">أخرى (يرجى التوضيح للسكرتير)</option>
                        </select>
                      </div>
                    </div>
                  )}

                  {step === 4 && (
                    <div className="space-y-4">
                      <div className="flex flex-col sm:flex-row gap-4">
                        <div className="flex-1">
                          <label className="block text-sm font-medium text-slate-700 mb-1">التاريخ المفضل</label>
                          <input
                            type="date"
                            value={formData.date}
                            onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                            className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-teal-500 focus:border-teal-500 outline-none transition-all"
                          />
                        </div>
                        <div className="flex-1">
                          <label className="block text-sm font-medium text-slate-700 mb-1">الوقت المفضل</label>
                          <input
                            type="time"
                            value={formData.time}
                            onChange={(e) => setFormData({ ...formData, time: e.target.value })}
                            className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-teal-500 focus:border-teal-500 outline-none transition-all"
                          />
                        </div>
                      </div>
                      
                      <div className="mt-6 p-4 bg-amber-50 border border-amber-100 rounded-xl">
                        <p className="text-sm text-amber-800 font-medium flex items-start gap-2">
                          <span className="text-amber-500 mt-0.5">💡</span>
                          ملاحظة: كشفية الطبيب تبلغ 50,000 دينار عراقي تُدفع عند الحضور للعيادة.
                        </p>
                      </div>
                    </div>
                  )}
                </motion.div>
              </AnimatePresence>
            </div>

            {/* Footer Actions */}
            <div className="p-6 border-t border-slate-100 bg-slate-50/50 flex items-center justify-between">
              <button
                onClick={handlePrev}
                disabled={step === 1}
                className={`flex items-center gap-1 px-4 py-2 rounded-lg font-medium transition-colors ${
                  step === 1 ? 'text-slate-300 cursor-not-allowed' : 'text-slate-600 hover:bg-slate-200'
                }`}
              >
                <ChevronRight className="w-5 h-5" />
                السابق
              </button>

              {step < totalSteps ? (
                <button
                  onClick={handleNext}
                  disabled={!isStepValid()}
                  className={`flex items-center gap-1 px-6 py-2.5 rounded-xl font-bold transition-all ${
                    isStepValid()
                      ? 'bg-teal-600 text-white hover:bg-teal-700 shadow-md hover:shadow-lg'
                      : 'bg-slate-200 text-slate-400 cursor-not-allowed'
                  }`}
                >
                  التالي
                  <ChevronLeft className="w-5 h-5" />
                </button>
              ) : (
                <button
                  onClick={handleSubmit}
                  disabled={!isStepValid()}
                  className={`flex items-center gap-2 px-8 py-2.5 rounded-xl font-bold transition-all ${
                    isStepValid()
                      ? 'bg-teal-600 text-white hover:bg-teal-700 shadow-md hover:shadow-lg'
                      : 'bg-slate-200 text-slate-400 cursor-not-allowed'
                  }`}
                >
                  تأكيد الحجز
                  <CheckCircle2 className="w-5 h-5" />
                </button>
              )}
            </div>
          </>
        )}
      </motion.div>
    </div>
  );
}
