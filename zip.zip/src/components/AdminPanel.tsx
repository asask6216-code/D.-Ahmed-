import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Trash2, CheckCircle, Clock, XCircle } from 'lucide-react';
import { useBookingStore, Booking } from '../store/bookingStore';

interface AdminPanelProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function AdminPanel({ isOpen, onClose }: AdminPanelProps) {
  const { bookings, updateStatus, deleteBooking } = useBookingStore();
  const [filter, setFilter] = useState<'الكل' | 'جديد' | 'مؤكد' | 'ملغي'>('الكل');

  if (!isOpen) return null;

  const filteredBookings = bookings.filter((b: Booking) => filter === 'الكل' || b.status === filter);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'جديد': return 'bg-blue-100 text-blue-700 border-blue-200';
      case 'مؤكد': return 'bg-teal-100 text-teal-700 border-teal-200';
      case 'ملغي': return 'bg-red-100 text-red-700 border-red-200';
      default: return 'bg-slate-100 text-slate-700 border-slate-200';
    }
  };

  return (
    <div className="fixed inset-0 z-[200] flex items-center justify-center p-4 sm:p-6">
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        onClick={onClose}
        className="absolute inset-0 bg-slate-900/80 backdrop-blur-sm"
      />
      
      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 20 }}
        className="relative w-full max-w-5xl bg-slate-50 rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]"
      >
        {/* Header */}
        <div className="px-6 py-5 border-b border-slate-200 bg-white flex items-center justify-between">
          <div>
            <h3 className="text-xl font-bold text-slate-900">لوحة تحكم السكرتارية</h3>
            <p className="text-sm text-slate-500 mt-1">إدارة حجوزات المرضى من الموقع الإلكتروني</p>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-slate-600 hover:bg-slate-100 rounded-full transition-colors"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Filters */}
        <div className="px-6 py-4 bg-white border-b border-slate-200 flex gap-2 overflow-x-auto">
          {['الكل', 'جديد', 'مؤكد', 'ملغي'].map((f) => (
            <button
              key={f}
              onClick={() => setFilter(f as any)}
              className={`px-4 py-2 rounded-full text-sm font-medium whitespace-nowrap transition-colors ${
                filter === f
                  ? 'bg-slate-800 text-white'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              {f}
              {f !== 'الكل' && (
                <span className="mr-2 px-2 py-0.5 rounded-full bg-white/20 text-xs">
                  {bookings.filter((b: Booking) => b.status === f).length}
                </span>
              )}
            </button>
          ))}
        </div>

        {/* Content */}
        <div className="p-6 flex-1 overflow-y-auto">
          {filteredBookings.length === 0 ? (
            <div className="text-center py-20">
              <div className="w-20 h-20 bg-slate-100 rounded-full flex items-center justify-center mx-auto mb-4 text-slate-400">
                <Clock className="w-10 h-10" />
              </div>
              <h4 className="text-lg font-medium text-slate-900">لا توجد حجوزات</h4>
              <p className="text-slate-500">لم يتم العثور على أي حجوزات تطابق الفلتر الحالي.</p>
            </div>
          ) : (
            <div className="grid gap-4">
              <AnimatePresence>
                {filteredBookings.map((booking: Booking) => (
                  <motion.div
                    key={booking.id}
                    layout
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, scale: 0.95 }}
                    className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex flex-col md:flex-row gap-6 items-start md:items-center justify-between"
                  >
                    <div className="flex-1 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                      <div>
                        <p className="text-xs text-slate-500 mb-1">المريض</p>
                        <p className="font-bold text-slate-900">{booking.name}</p>
                        <p className="text-sm text-slate-600">{booking.age} سنة</p>
                      </div>
                      <div>
                        <p className="text-xs text-slate-500 mb-1">التواصل</p>
                        <p className="font-medium text-slate-900" dir="ltr">{booking.phone}</p>
                      </div>
                      <div>
                        <p className="text-xs text-slate-500 mb-1">الخدمة</p>
                        <p className="font-medium text-teal-700">{booking.service}</p>
                      </div>
                      <div>
                        <p className="text-xs text-slate-500 mb-1">الموعد</p>
                        <p className="font-medium text-slate-900">{booking.date}</p>
                        <p className="text-sm text-slate-600">{booking.time}</p>
                      </div>
                    </div>

                    <div className="flex items-center gap-3 w-full md:w-auto pt-4 md:pt-0 border-t md:border-t-0 border-slate-100">
                      <select
                        value={booking.status}
                        onChange={(e) => updateStatus(booking.id, e.target.value as any)}
                        className={`px-3 py-2 rounded-lg text-sm font-bold border outline-none cursor-pointer ${getStatusColor(booking.status)}`}
                      >
                        <option value="جديد">جديد</option>
                        <option value="مؤكد">مؤكد</option>
                        <option value="ملغي">ملغي</option>
                      </select>
                      
                      <button
                        onClick={() => {
                          if (window.confirm('هل أنت متأكد من حذف هذا الحجز؟')) {
                            deleteBooking(booking.id);
                          }
                        }}
                        className="p-2 text-red-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                        title="حذف الحجز"
                      >
                        <Trash2 className="w-5 h-5" />
                      </button>
                    </div>
                  </motion.div>
                ))}
              </AnimatePresence>
            </div>
          )}
        </div>
      </motion.div>
    </div>
  );
}
