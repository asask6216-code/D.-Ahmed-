import { motion } from 'motion/react';
import { Award, CheckCircle2, GraduationCap, Stethoscope } from 'lucide-react';

export default function AboutDoctor() {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, x: 20 },
    visible: { opacity: 1, x: 0, transition: { duration: 0.5 } },
  };

  return (
    <section id="about" className="py-24 bg-white overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col lg:flex-row items-center gap-16">
          
          {/* Doctor Image with Spring Animation */}
          <motion.div
            initial={{ opacity: 0, scale: 0.8, rotate: -5 }}
            whileInView={{ opacity: 1, scale: 1, rotate: 0 }}
            viewport={{ once: true, margin: "-100px" }}
            transition={{ type: "spring", stiffness: 100, damping: 20 }}
            className="w-full lg:w-1/2 relative"
          >
            <div className="relative rounded-3xl overflow-hidden shadow-2xl aspect-[4/5] max-w-md mx-auto">
              <img
                src="https://picsum.photos/seed/doctor/800/1000"
                alt="دكتور أحمد"
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-900/40 to-transparent"></div>
            </div>
            
            {/* Pop-up Badge */}
            <motion.div
              initial={{ opacity: 0, scale: 0, y: 20 }}
              whileInView={{ opacity: 1, scale: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.5, type: "spring", stiffness: 200, damping: 15 }}
              className="absolute -bottom-6 -right-6 md:bottom-10 md:-right-10 bg-white p-4 rounded-2xl shadow-xl border border-slate-100 flex items-center gap-4"
            >
              <div className="w-12 h-12 bg-teal-100 rounded-full flex items-center justify-center text-teal-600">
                <Award className="w-6 h-6" />
              </div>
              <div>
                <p className="text-2xl font-bold text-slate-900">15+</p>
                <p className="text-sm text-slate-500 font-medium">سنة خبرة</p>
              </div>
            </motion.div>
          </motion.div>

          {/* Doctor Info */}
          <motion.div
            variants={containerVariants}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-100px" }}
            className="w-full lg:w-1/2"
          >
            <motion.div variants={itemVariants} className="flex items-center gap-2 text-teal-600 font-semibold mb-4">
              <Stethoscope className="w-5 h-5" />
              <span>عن الطبيب</span>
            </motion.div>
            
            <motion.h2 variants={itemVariants} className="text-3xl md:text-4xl font-bold text-slate-900 mb-6">
              د. أحمد محمد
            </motion.h2>
            
            <motion.p variants={itemVariants} className="text-lg text-slate-600 mb-8 leading-relaxed">
              طبيب أسنان استشاري متخصص في زراعة وتجميل الأسنان. يكرس جهده لتقديم أفضل مستويات الرعاية الصحية باستخدام أحدث التقنيات العالمية لضمان راحة المريض ونتائج مثالية.
            </motion.p>

            <div className="space-y-4">
              {[
                { icon: GraduationCap, text: 'بكالوريوس طب وجراحة الفم والأسنان' },
                { icon: CheckCircle2, text: 'البورد في زراعة الأسنان' },
                { icon: CheckCircle2, text: 'عضو الجمعية العالمية لتجميل الأسنان' },
                { icon: CheckCircle2, text: 'خبرة واسعة في الحالات المعقدة وإعادة تأهيل الفم' },
              ].map((item, index) => (
                <motion.div
                  key={index}
                  variants={itemVariants}
                  className="flex items-center gap-3 group"
                >
                  <div className="w-8 h-8 rounded-full bg-teal-50 flex items-center justify-center text-teal-600 group-hover:bg-teal-600 group-hover:text-white transition-colors">
                    <item.icon className="w-4 h-4" />
                  </div>
                  <span className="text-slate-700 font-medium">{item.text}</span>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
