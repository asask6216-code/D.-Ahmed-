import { motion } from 'motion/react';
import { ArrowLeft, Sparkles, Syringe, Activity, Smile, ShieldCheck } from 'lucide-react';

interface ServicesProps {
  onBookService: (serviceName: string) => void;
}

export default function Services({ onBookService }: ServicesProps) {
  const services = [
    {
      id: 'consultation',
      title: 'كشفية طبية واستشارة',
      price: '50,000 د.ع',
      icon: Activity,
      description: 'فحص شامل للأسنان واللثة مع وضع خطة علاجية متكاملة.',
    },
    {
      id: 'implants',
      title: 'زراعة الأسنان',
      price: 'يبدأ من 500,000 د.ع',
      icon: ShieldCheck,
      description: 'استعاضة الأسنان المفقودة بأحدث تقنيات الزراعة التيتانيوم.',
    },
    {
      id: 'endo',
      title: 'علاج العصب',
      price: 'يبدأ من 100,000 د.ع',
      icon: Syringe,
      description: 'علاج جذور الأسنان بدون ألم باستخدام الأجهزة الدوارة.',
    },
    {
      id: 'hollywood',
      title: 'ابتسامة هوليود',
      price: 'استشارة',
      icon: Smile,
      description: 'تصميم ابتسامة مثالية باستخدام قشور الفينير أو اللومينير.',
    },
    {
      id: 'gums',
      title: 'تجميل اللثة',
      price: 'استشارة',
      icon: Sparkles,
      description: 'قص وتوريد اللثة بالليزر لابتسامة أكثر تناسقاً وجمالاً.',
    },
  ];

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
      },
    },
  };

  const cardVariants = {
    hidden: { opacity: 0, y: 30 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.5 } },
  };

  return (
    <section id="services" className="py-24 bg-slate-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-slate-900 mb-4">خدماتنا الطبية</h2>
          <p className="text-slate-600 text-lg">
            نقدم مجموعة شاملة من خدمات طب الفم والأسنان بأعلى معايير الجودة والتعقيم.
          </p>
        </div>

        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-50px" }}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
        >
          {services.map((service) => (
            <motion.div
              key={service.id}
              variants={cardVariants}
              className="group bg-white rounded-2xl p-6 border border-slate-100 transition-all duration-300 hover:-translate-y-2 hover:shadow-2xl hover:shadow-teal-900/5 relative overflow-hidden"
            >
              {/* Hover Background Accent */}
              <div className="absolute top-0 right-0 w-32 h-32 bg-teal-50 rounded-bl-full -z-10 transition-transform duration-500 group-hover:scale-150 opacity-50"></div>
              
              <div className="w-12 h-12 rounded-xl bg-teal-50 text-teal-600 flex items-center justify-center mb-6 transition-colors duration-300 group-hover:bg-teal-600 group-hover:text-white">
                <service.icon className="w-6 h-6" />
              </div>
              
              <h3 className="text-xl font-bold text-slate-900 mb-2">{service.title}</h3>
              <p className="text-slate-600 mb-4 text-sm leading-relaxed min-h-[40px]">
                {service.description}
              </p>
              
              <div className="flex items-center justify-between mt-6 pt-4 border-t border-slate-100">
                <span className="font-semibold text-teal-700">{service.price}</span>
                <button
                  onClick={() => onBookService(service.title)}
                  className="flex items-center gap-2 text-sm font-bold text-slate-900 group-hover:text-teal-600 transition-colors"
                >
                  احجز هذه الخدمة
                  <ArrowLeft className="w-4 h-4 opacity-0 -translate-x-2 transition-all duration-300 group-hover:opacity-100 group-hover:translate-x-0" />
                </button>
              </div>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}
