import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { MapPin, Phone, Mail, ArrowUp, Stethoscope } from 'lucide-react';

interface FooterProps {
  onOpenAdmin: () => void;
}

export default function Footer({ onOpenAdmin }: FooterProps) {
  const [showBackToTop, setShowBackToTop] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setShowBackToTop(window.scrollY > 500);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="bg-slate-900 text-slate-300 py-12 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-8 border-b border-slate-800 pb-8">
          
          {/* Brand */}
          <div>
            <div className="flex items-center gap-2 text-white mb-4">
              <Stethoscope className="w-8 h-8 text-teal-500" />
              <span className="font-bold text-xl">عيادة د. أحمد</span>
            </div>
            <p className="text-sm text-slate-400 leading-relaxed">
              نلتزم بتقديم أفضل رعاية صحية لأسنانك باستخدام أحدث التقنيات العالمية في بيئة آمنة ومريحة.
            </p>
          </div>

          {/* Contact Info */}
          <div>
            <h4 className="text-white font-bold mb-4">معلومات التواصل</h4>
            <ul className="space-y-3 text-sm">
              <li className="flex items-start gap-3">
                <MapPin className="w-5 h-5 text-teal-500 shrink-0 mt-0.5" />
                <a 
                  href="https://maps.app.goo.gl/qkKDXKe841aQq3kP6" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="hover:text-teal-400 transition-colors"
                >
                  بغداد، شارع الأطباء، مجمع الشفاء الطبي، الطابق الثاني
                </a>
              </li>
              <li className="flex items-center gap-3">
                <Phone className="w-5 h-5 text-teal-500 shrink-0" />
                <span dir="ltr">+964 123 456 7890</span>
              </li>
              <li className="flex items-center gap-3">
                <Mail className="w-5 h-5 text-teal-500 shrink-0" />
                <span>info@dr-ahmed-clinic.com</span>
              </li>
            </ul>
          </div>

          {/* Working Hours */}
          <div>
            <h4 className="text-white font-bold mb-4">ساعات العمل</h4>
            <ul className="space-y-2 text-sm">
              <li className="flex justify-between">
                <span>السبت - الخميس:</span>
                <span>10:00 ص - 08:00 م</span>
              </li>
              <li className="flex justify-between text-teal-500">
                <span>الجمعة:</span>
                <span>مغلق</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="flex flex-col md:flex-row items-center justify-between text-xs text-slate-500">
          <p>© {new Date().getFullYear()} عيادة د. أحمد لطب الأسنان. جميع الحقوق محفوظة.</p>
          <button 
            onClick={onOpenAdmin}
            className="mt-4 md:mt-0 hover:text-slate-300 transition-colors opacity-50 hover:opacity-100"
          >
            لوحة تحكم السكرتارية
          </button>
        </div>
      </div>

      {/* Back to Top Button */}
      <AnimatePresence>
        {showBackToTop && (
          <motion.button
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 20 }}
            onClick={scrollToTop}
            className="fixed bottom-6 left-6 z-40 bg-slate-800 text-white p-3 rounded-full shadow-lg hover:bg-teal-600 transition-colors"
          >
            <ArrowUp className="w-5 h-5" />
          </motion.button>
        )}
      </AnimatePresence>
    </footer>
  );
}
