import { useState, useEffect } from 'react';

export interface Booking {
  id: string;
  name: string;
  age: string;
  phone: string;
  service: string;
  date: string;
  time: string;
  status: 'جديد' | 'مؤكد' | 'ملغي';
  createdAt: string;
}

// Simple pub/sub for cross-component state
const listeners = new Set<() => void>();

const getBookings = (): Booking[] => {
  try {
    const data = localStorage.getItem('clinic_bookings');
    return data ? JSON.parse(data) : [];
  } catch {
    return [];
  }
};

const setBookings = (bookings: Booking[]) => {
  localStorage.setItem('clinic_bookings', JSON.stringify(bookings));
  listeners.forEach((listener) => listener());
};

export const useBookingStore = (selector?: any) => {
  const [bookings, setLocalBookings] = useState<Booking[]>(getBookings());

  useEffect(() => {
    const listener = () => setLocalBookings(getBookings());
    listeners.add(listener);
    return () => {
      listeners.delete(listener);
    };
  }, []);

  const addBooking = (booking: Booking) => {
    const current = getBookings();
    setBookings([booking, ...current]);
  };

  const updateStatus = (id: string, status: Booking['status']) => {
    const current = getBookings();
    setBookings(current.map((b) => (b.id === id ? { ...b, status } : b)));
  };

  const deleteBooking = (id: string) => {
    const current = getBookings();
    setBookings(current.filter((b) => b.id !== id));
  };

  // Mimic Zustand selector behavior for the specific use case
  if (selector) {
    return selector({ bookings, addBooking, updateStatus, deleteBooking });
  }

  return { bookings, addBooking, updateStatus, deleteBooking };
};
