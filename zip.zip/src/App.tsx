import { useState } from 'react';
import { Stethoscope } from 'lucide-react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import AboutDoctor from './components/AboutDoctor';
import Services from './components/Services';
import BookingModal from './components/BookingModal';
import AdminPanel from './components/AdminPanel';
import Footer from './components/Footer';
import FloatingWhatsApp from './components/FloatingWhatsApp';
import ScrollProgress from './components/ScrollProgress';

export default function App() {
  const [isBookingOpen, setIsBookingOpen] = useState(false);
  const [isAdminOpen, setIsAdminOpen] = useState(false);
  const [selectedService, setSelectedService] = useState('');

  const handleBookClick = (serviceName: string = '') => {
    setSelectedService(serviceName);
    setIsBookingOpen(true);
  };

  return (
    <div className="min-h-screen bg-slate-50 font-sans text-slate-900 selection:bg-teal-200 selection:text-teal-900">
      <ScrollProgress />
      
      <Navbar 
        clinicName="عيادة د. أحمد" 
        Icon={Stethoscope} 
        onBookClick={() => handleBookClick()} 
      />
      
      <main>
        <Hero onBookClick={() => handleBookClick()} />
        <AboutDoctor />
        <Services onBookService={handleBookClick} />
      </main>

      <Footer onOpenAdmin={() => setIsAdminOpen(true)} />
      
      <FloatingWhatsApp />

      <BookingModal 
        isOpen={isBookingOpen} 
        onClose={() => setIsBookingOpen(false)} 
        initialService={selectedService}
      />
      
      <AdminPanel 
        isOpen={isAdminOpen} 
        onClose={() => setIsAdminOpen(false)} 
      />
    </div>
  );
}
